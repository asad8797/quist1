package com.example.abdazizs.quiz1;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


public class Biodata extends AppCompatActivity{
    private Button btnKm,btnKl;
    private ImageView im;
    private LinearLayout lnVer1,lnHor,lnVer2;

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.bio);

        btnKm = (Button) findViewById(R.id.btnKmr);
        im = (ImageView) findViewById(R.id.imgBio);

        lnVer1 = (LinearLayout) findViewById(R.id.verOne);
        lnHor = (LinearLayout) findViewById(R.id.horOne);
        lnVer2 = (LinearLayout) findViewById(R.id.verTwo);
        lnVer1.setBackgroundColor(Color.rgb(88,214,141));
        lnHor.setBackgroundColor(Color.rgb(255,255,255));

        im.setImageResource(R.drawable.gading);

        btnKm.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(i);
            }
        });
    }
}
