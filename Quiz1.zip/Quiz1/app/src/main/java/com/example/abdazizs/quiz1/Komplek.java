package com.example.abdazizs.quiz1;

public class Komplek {
    String nama,julukan;

    public Komplek(String na,String julukan){
        this.nama=na;
        this.julukan=julukan;
    }
    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getJulukan() {
        return julukan;
    }

    public void setJulukan(String julukan) {
        this.julukan = julukan;
    }

}
