package com.example.abdazizs.quiz1;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.content.Intent;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rvView;
    private RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private ArrayList<Komplek> dataSet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        dataSet = new ArrayList<Komplek>();
        initDataset();

        rvView = (RecyclerView) findViewById(R.id.rv_main);
        rvView.setHasFixedSize(true);
        /**
         * Kita menggunakan LinearLayoutManager untuk list standar
         * yang hanya berisi daftar item
         * disusun dari atas ke bawah
         */
        layoutManager = new LinearLayoutManager(this);
        rvView.setLayoutManager(layoutManager);

        adapter = new RecyclerViewAdapter(dataSet);
        rvView.setAdapter(adapter);
//        btnImg.setOnClickListener(){
//
//        };


    }
    private void initDataset(){
        /**
         * Tambahkan item ke dataset
         * dalam prakteknya bisa bermacam2
         * tidak hanya String seperti di kasus ini
         */
        dataSet.add(new Komplek("Komplek A","Sunan Bonang"));
        dataSet.add(new Komplek("Komplek B","Sunan Ampel"));
        dataSet.add(new Komplek("Komplek C","Sunan Giri"));
        dataSet.add(new Komplek("Komplek D","Sunan Maulana Malik Ibrahim"));
        dataSet.add(new Komplek("Komplek E","Sunan Qudus"));
        dataSet.add(new Komplek("Komplek F","Sunan Gunung Jati"));
        dataSet.add(new Komplek("Komplek G","Sunan Drajat"));
        dataSet.add(new Komplek("Komplek H","Sunan Kalijaga"));
        dataSet.add(new Komplek("Komplek I","Sunan Muria"));

    }
}
