package com.example.abdazizs.quiz1.adapters;

import android.support.v7.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.View;

public class RecyclerTouchListener implements RecyclerView.OnClickListener {

    private GestureDetector gD;
    private ClickListener cL;

    @Override
    public void onClick(View view) {

    }

}
